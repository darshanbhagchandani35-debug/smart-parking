# SmartPark Full-Stack Parking Management Demo

## Run on Windows / VS Code
1. Install Node.js 18 or newer.
2. Extract the ZIP and open this folder in VS Code.
3. Open Terminal > New Terminal.
4. Run `npm start`.
5. Open `http://localhost:3000` (do not open `index.html` directly).

## Demo staff logins
- Administrator: `admin@smartpark.local` / `Admin@12345`
- Attendant: `attendant@smartpark.local` / `Attendant@12345`
- Create a normal User account from the registration form.

## Included
- JSON-backed database file (`data.json`) and REST API routes.
- User registration/login (passwords hashed with Node scrypt), role checks, and session tokens.
- Server-validated reservations, fixed ₹30/hour fee, slot/date conflict prevention, cancellation/refund-status records.
- Slot states (Available, Reserved, Occupied, Maintenance).
- QR parking ticket generation; attendant entry/exit actions and extra-charge calculation.
- Admin overview, bookings, user count, payment records and revenue metric.
- Map search using embedded Google Maps; payment options are demo only.
- Contact messages persisted on server.

## Important demo limitations
- The online QR payment is not connected to a payment gateway and does not verify real UPI payments. Integrate a provider (e.g. Razorpay) in test mode before claiming online payment support.
- JSON file storage is appropriate for a college demo, not production multi-process deployments. Use MySQL/PostgreSQL transactions and a persistent session store for production.
- Map embeds need an internet connection. Location discovery is map search, not a verified inventory of nearby commercial parking lots.
- Attendant QR workflow currently accepts a ticket's booking ID or token entered into the staff form; camera-based QR scanning can be added separately.
- Slot seed states are demo data. Admin/attendant can update states. Revenue excludes unverified online/cash-pending payments.
